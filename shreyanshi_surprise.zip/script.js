// Tiny sparkle interaction: the page stays fully usable without JavaScript.
document.querySelectorAll('a[href^="#"]').forEach(link => {
  link.addEventListener('click', () => {
    const target = document.querySelector(link.getAttribute('href'));
    if (target) target.scrollIntoView({behavior: 'smooth', block: 'start'});
  });
});


// Prevent missing gallery images from appearing as empty spaces.
document.querySelectorAll('.gallery-card img').forEach((img) => {
  const showFallback = () => {
    const card = img.closest('.gallery-card');
    if (!card || card.classList.contains('image-missing')) return;
    card.classList.add('image-missing');
    card.dataset.message = 'Photo not found: ' + img.getAttribute('src') + '. Check that this file exists in the assets folder.';
    img.style.display = 'none';
  };
  img.addEventListener('error', showFallback);
  if (img.complete && img.naturalWidth === 0) showFallback();
});
