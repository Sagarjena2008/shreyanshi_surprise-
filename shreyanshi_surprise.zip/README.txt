SHREYANSHI (BHUMI) BIRTHDAY WEBSITE — FIXED PACKAGE

This package includes all three pages, the stylesheet, JavaScript, and the real image files in the assets folder.

FILES AT THE PROJECT ROOT
- index.html      Home page
- greetings.html  Birthday wishes
- gallery.html    Photo memories
- style.css       Styling and responsive layout
- script.js       Navigation and missing-image fallback
- assets/         All photos/poster used by the pages

RUN LOCALLY
1. Extract this ZIP file.
2. Open the extracted folder.
3. Double-click index.html.

PUBLISH ON GITHUB PAGES
1. Open your GitHub repository.
2. Upload the CONTENTS of this folder, not the enclosing folder itself.
3. Ensure index.html, greetings.html, gallery.html, style.css, script.js, and the assets folder are all at the repository root.
4. Commit the files.
5. Open Settings > Pages, choose Deploy from a branch, select main and /(root), then Save.
6. Open the website URL provided by GitHub Pages.

IMPORTANT
Do not upload only the HTML files. The assets folder contains the actual photographs. Keep the folder name assets and all filenames unchanged. The gallery now shows a helpful placeholder if a photo path is wrong instead of leaving a blank area.
